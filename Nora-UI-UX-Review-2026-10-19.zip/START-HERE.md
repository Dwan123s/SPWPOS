# Nora UI/UX review package

Snapshot: 19 October 2026, from the current main workspace, including uncommitted UI patches.

Start with docs/reviews/NORA_UI_UX_HANDOFF.md for the file inventory and docs/reviews/NORA_UI_UX_AUDIT_2026-10-19.md for findings, changes, verification and screenshots.

Included:
- Complete frontend source and tests, package.json, lockfile and Vite configuration.
- Three Nora mascot/sprite assets at their original repository paths.
- Handoff and audit documents, their linked screenshots and test output.
- PACKAGE-MANIFEST.json with SHA-256 hashes of all other archived files.

The current menu floats without moving rows. Both delete entry points use the same centered confirmation dialog. The top delete action is an icon only.

This is a source review package, not a deployed application or standalone backend. Running the authenticated app requires the SPWPOS backend, configuration and other application assets from the full repository. Dependencies are not installed in this archive. The screenshots use synthetic data.

Excluded: node_modules, compiled bundles, backend source/configuration, local environment files and credentials.

Validation of this snapshot: 248 frontend tests, 4 session tests and the production frontend build passed. See the audit for scope and limitations.
