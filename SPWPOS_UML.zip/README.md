# SPWPOS UML — bản cải thiện mô hình Use Case

Bản này gồm **một ảnh toàn hệ thống có đủ 72 use case riêng biệt** và **tám ảnh từng nhóm chức năng**. Mỗi UC trong ảnh toàn hệ thống giữ nguyên ID, tên và quan hệ; không thay các UC bằng một ellipse tóm tắt.
Các sơ đồ là những góc nhìn của cùng một hệ thống; một UC được tham chiếu ở hai
hình vẫn là cùng một yêu cầu, không được đếm hai lần.

## Cách dùng trong báo cáo SWP391

1. Mở `UseCase/SPWPOS_UseCase_00_Complete_System.svg` để xem toàn bộ hệ thống.
   Ảnh này có đủ 72 ellipse UC01–UC72, chia thành 8 vùng chức năng bên trong
   cùng ranh giới SPWPOS, với đầy đủ actor association và include/extend.
   PNG cùng tên là bản raster của cùng ảnh. Dùng SVG khi cần phóng to.
2. Đưa tám sơ đồ `01` đến `08` vào các phần chức năng tương ứng.
3. Dùng `Documentation/USE_CASE_INDEX.md` để đối chiếu ID, actor và phân hệ.
4. Đọc `Documentation/MODEL_REVIEW.md` trước khi chốt đặc tả: tài liệu này ghi
   các giả định và lý do giữ/bỏ từng quan hệ. Đối chiếu với báo cáo gốc của nhóm.
5. Điền đặc tả use case theo template giảng viên cung cấp. Bộ ZIP này chưa phải
   tài liệu SRS/RDS đầy đủ và chưa được đối chiếu rubric riêng của lớp.

SVG giữ nét khi phóng to và phù hợp chèn vào báo cáo. PNG dùng khi phần mềm
không hỗ trợ SVG. Ảnh toàn hệ thống lớn, cần phóng to để đọc hoặc đặt trên trang khổ lớn.
Các sơ đồ riêng như Task/Planning nên chiếm một trang riêng,
không thu nhỏ nhiều sơ đồ vào một trang khiến chữ không đọc được.

## Quy ước

- Actor nằm ngoài ranh giới `SPWPOS System`.
- Đường liền không đầu mũi tên biểu diễn actor tham gia use case.
- `include`: use case nguồn thực hiện hành vi được bao gồm, theo giả định đã ghi.
- `extend`: hành vi mở rộng tùy điều kiện được chèn tại extension point của UC gốc.
- Ellipse xanh, `supporting`: hành vi hệ thống được tái sử dụng. Đây là nhãn
  phân loại cục bộ của tài liệu, không phải stereotype UML chuẩn được định nghĩa sẵn.
- Ellipse xám viền đứt: UC thuộc phân hệ khác nhưng vẫn ở trong SPWPOS.
- Không dùng đường use case để biểu diễn thứ tự màn hình hoặc sự kiện bất đồng bộ.
- Đường nối chạm đúng viền ellipse. Ưu tiên nét thẳng; dùng nét gấp khúc khi cần
  tránh một actor/ellipse khác. Không dùng đường cong Bézier. Đường có thể giao
  nhau hoặc dùng chung đoạn; không được hiểu giao điểm là một nút UML mới.

## Chỉnh sửa và tạo lại

Danh mục và quan hệ: `Tools/usecases.py`.
Generator: `Tools/gen_uc.py`, dùng đường dẫn tương đối với chính script.

```bash
python Tools/gen_uc.py
python Tools/render_uc.py --jar /absolute/path/to/plantuml.jar
python Tools/validate_uc.py
```

Môi trường tạo ảnh đã kiểm tra: Java 17, PlantUML 1.2025.4, Inkscape và Pillow.
`render_uc.py` dùng Smetana nên không cần Graphviz. Nếu Smetana sinh ranh giới
ở tọa độ âm, script chỉnh khung SVG, vị trí tiêu đề và tạo PNG tương ứng bằng
Inkscape; các actor, ellipse và quan hệ không thay đổi. Java, Inkscape và Pillow
cần có khi chạy lại quy trình này. `route_uc.py` tính điểm chạm theo phương trình
ellipse, chọn đường thẳng hoặc các đoạn vuông góc, rồi renderer tạo PNG từ chính
SVG đó. Chạy đầy đủ `render_uc.py` để giữ cách nối này; xuất trực tiếp bằng một
plugin PlantUML khác có thể dùng lại kiểu nối mặc định của plugin.
`full_system_uc.py` sắp toàn bộ 72 glyph UC từ tám hình chi tiết vào một canvas
chung, rồi nối từng UC riêng theo đúng danh mục và quan hệ trong `usecases.py`.
Không nối actor vào khung nhóm thay cho UC. File `.puml` toàn hệ thống chứa
đủ cùng 72 UC và quan hệ; bố cục chính xác của ảnh được tạo bằng renderer này.
PlantUML jar không được đóng gói trong ZIP.

## Cấu trúc

| Thư mục | Nội dung |
|---|---|
| UseCase | 9 sơ đồ SVG và PNG đã tạo lại |
| Sources | PlantUML có thể chỉnh sửa |
| Documentation | Rà soát quan hệ, danh mục UC, ghi chú lịch sử |
| Tools | Spec, generator, renderer, kiểm tra mô hình; công cụ DB ban đầu |
| Database | Bộ ERD/SQL ban đầu, giữ nguyên |

## Tài liệu tham khảo

- [OMG UML 2.5.1](https://www.omg.org/spec/UML/2.5.1/) — đặc biệt phần UseCases.
- [Use Cases, Alexander Serebrenik, TU/e](https://aserebre.win.tue.nl/2IW80/2013-2014/02%20-%20UML%20Use%20Cases.pdf).
- [Enterprise Architect: Extend](https://www.sparxsystems.org/enterprise_architect_user_guide/17.2/modeling_languages/extend.html).
- [PlantUML Use Case syntax](https://plantuml.com/use-case-diagram).

Template/rubric SWP391 hiện hành của lớp vẫn là cơ sở để quyết định cách nộp.
