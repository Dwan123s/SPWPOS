# Danh mục Use Case và nhóm chức năng

Ảnh toàn hệ thống hiển thị riêng từng UC01–UC72. Các khung nhóm chỉ tổ chức bố cục; actor nối trực tiếp vào UC, không nối vào khung thay cho UC.

| Nhóm chức năng | Use case trong ảnh toàn hệ thống | Ảnh riêng |
|---|---|---|
| Account & Profile | UC01–UC08 | SPWPOS_UseCase_01_ACC |
| Task Management | UC09–UC26 | SPWPOS_UseCase_02_TASK |
| Time Management | UC27–UC35 | SPWPOS_UseCase_03_TIME |
| Planning & Scheduling | UC36–UC49 | SPWPOS_UseCase_04_PLAN |
| Execution & Feedback | UC50–UC57 | SPWPOS_UseCase_05_EXEC |
| Intelligence & Personalization | UC58–UC64 | SPWPOS_UseCase_06_INTEL |
| Notification | UC65–UC68 | SPWPOS_UseCase_07_NOTI |
| Administration | UC69–UC72 | SPWPOS_UseCase_08_ADMIN |

## Danh mục chi tiết

Actor ghi dưới đây là đối tượng trực tiếp tham gia, không phải mọi người hưởng
lợi từ kết quả. “Không có trực tiếp” không có nghĩa là use case không có người
hưởng lợi: UC supporting được use case khác bao gồm.

| ID | Use case | Phân hệ | Phân loại | Actor trực tiếp |
|---|---|---|---|---|
| UC01 | Register Account | ACC | Actor goal | User |
| UC02 | Login | ACC | Actor goal | User |
| UC03 | Logout | ACC | Actor goal | User |
| UC04 | Request Password Reset | ACC | Actor goal | User |
| UC05 | Reset Password | ACC | Actor goal | User |
| UC06 | Change Password | ACC | Actor goal | User |
| UC07 | View Profile | ACC | Actor goal | User |
| UC08 | Update Profile | ACC | Actor goal | User |
| UC09 | Create Task | TASK | Actor goal | User |
| UC10 | View Task List | TASK | Actor goal | User |
| UC11 | View Task Details | TASK | Actor goal | User |
| UC12 | Update Task | TASK | Actor goal | User |
| UC13 | Delete Task | TASK | Actor goal | User |
| UC14 | Search Tasks | TASK | Actor goal | User |
| UC15 | Filter Tasks | TASK | Actor goal | User |
| UC16 | Change Task Status | TASK | Actor goal | User |
| UC17 | Create Task Category | TASK | Actor goal | User |
| UC18 | Update Task Category | TASK | Actor goal | User |
| UC19 | Delete Task Category | TASK | Actor goal | User |
| UC20 | Create Subtask | TASK | Actor goal | User |
| UC21 | Update Subtask | TASK | Actor goal | User |
| UC22 | Delete Subtask | TASK | Actor goal | User |
| UC23 | Add Task Dependency | TASK | Actor goal | User |
| UC24 | Remove Task Dependency | TASK | Actor goal | User |
| UC25 | Capture Task Using Natural Language | TASK | Actor goal | User, External AI Service |
| UC26 | Break Down Complex Task | TASK | Actor goal | User, External AI Service |
| UC27 | Set Weekly Availability | TIME | Actor goal | User |
| UC28 | Add Availability Exception | TIME | Actor goal | User |
| UC29 | Update Availability Exception | TIME | Actor goal | User |
| UC30 | Remove Availability Exception | TIME | Actor goal | User |
| UC31 | Create Fixed Event | TIME | Actor goal | User |
| UC32 | Update Fixed Event | TIME | Actor goal | User |
| UC33 | Delete Fixed Event | TIME | Actor goal | User |
| UC34 | View Personal Calendar | TIME | Actor goal | User |
| UC35 | Set Work Preferences | TIME | Actor goal | User |
| UC36 | Generate Work Plan | PLAN | Actor goal | User |
| UC37 | Review Proposed Plan | PLAN | Actor goal | User |
| UC38 | Apply Proposed Plan | PLAN | Actor goal | User |
| UC39 | Move Work Session | PLAN | Actor goal | User |
| UC40 | Change Work Session Duration | PLAN | Actor goal | User |
| UC41 | Lock Work Session | PLAN | Actor goal | User |
| UC42 | Unlock Work Session | PLAN | Actor goal | User |
| UC43 | Split Work Session | PLAN | Actor goal | User |
| UC44 | Detect Scheduling Conflict | PLAN | Supporting (A7) | Không có trực tiếp |
| UC45 | Generate Reschedule Proposal | PLAN | Actor goal | User |
| UC46 | Review Reschedule Proposal | PLAN | Actor goal | User |
| UC47 | Apply Reschedule Proposal | PLAN | Actor goal | User |
| UC48 | Explain Scheduling Decision | PLAN | Actor goal | User |
| UC49 | Run What-if Scenario | PLAN | Actor goal | User |
| UC50 | Start Work Session | EXEC | Actor goal | User |
| UC51 | Pause Work Session | EXEC | Actor goal | User |
| UC52 | Resume Work Session | EXEC | Actor goal | User |
| UC53 | Complete Work Session | EXEC | Actor goal | User |
| UC54 | Skip Work Session | EXEC | Actor goal | User |
| UC55 | Update Task Progress | EXEC | Actor goal | User |
| UC56 | Record Actual Work Duration | EXEC | Supporting (A7) | Không có trực tiếp |
| UC57 | Review Planned vs Actual Performance | EXEC | Actor goal | User |
| UC58 | Get Personalized Duration Estimate | INTEL | Supporting (A7) | Không có trực tiếp |
| UC59 | Review Estimation Bias | INTEL | Actor goal | User |
| UC60 | Review Effective Capacity | INTEL | Actor goal | User |
| UC61 | View Workload Analysis | INTEL | Actor goal | User |
| UC62 | View Overload Risk | INTEL | Actor goal | User |
| UC63 | View Task Completion Risk | INTEL | Actor goal | User |
| UC64 | View Personal Productivity Insights | INTEL | Actor goal | User |
| UC65 | Receive Deadline Notification | NOTI | Actor goal | User, Notification Service |
| UC66 | Receive Upcoming Work Session Reminder | NOTI | Actor goal | User, Notification Service |
| UC67 | Receive Workload Warning | NOTI | Actor goal | User, Notification Service |
| UC68 | Receive Schedule Change Notification | NOTI | Actor goal | User, Notification Service |
| UC69 | Search User Accounts | ADMIN | Actor goal | Administrator |
| UC70 | Lock User Account | ADMIN | Actor goal | Administrator |
| UC71 | Unlock User Account | ADMIN | Actor goal | Administrator |
| UC72 | View System Status | ADMIN | Actor goal | Administrator |
