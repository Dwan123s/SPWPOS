# Rà soát mô hình Use Case SPWPOS

## Phạm vi và căn cứ

Đầu vào: bộ UML hiện có với 72 UC, danh mục trong `Tools/usecases.py` và ghi chú
v2 trong `CHANGES.md` cũ. Không có bản đặc tả nghiệp vụ đầy đủ, mã ứng dụng hoặc
rubric của lớp trong ZIP. Vì vậy, đây là bản đề xuất mô hình đã chỉnh cấu trúc và
ký pháp, không phải xác nhận rằng mọi giả định đã được kiểm chứng với hệ thống.

Không đổi tên/ID của 72 UC. Không sửa ERD, SQL hoặc thêm tính năng sản phẩm.
Việc bỏ một đường quan hệ không xóa hành vi nghiệp vụ tương ứng; hành vi đó có
thể vẫn nằm ở tiền điều kiện, luồng xử lý, sự kiện hoặc quy tắc nghiệp vụ.

## Các giả định cần đối chiếu

| Mã | Giả định đã dùng | Nếu đặc tả thực tế khác |
|---|---|---|
| A1 | UC36 luôn dùng hành vi UC58 để lấy thời lượng cá nhân hóa, có thể dùng giá trị mặc định khi chưa đủ dữ liệu. | Nếu chỉ dùng tùy lựa chọn, bỏ `include` và mô tả nhánh điều kiện trong đặc tả. Không tự chuyển thành `extend` nếu chưa có điểm chèn. |
| A2 | UC36/39/40/43/45/49 luôn kiểm tra xung đột cho lịch hoặc phương án đang xét qua UC44. | Chỉ giữ các `include` mà luồng thực sự bắt buộc gọi; trường hợp tùy chọn phải được đặc tả lại. |
| A3 | UC53 luôn ghi nhận thời lượng thực tế qua UC56 khi kết thúc phiên. | Nếu thời lượng có thể không được ghi, sửa quan hệ và hậu điều kiện phù hợp. |
| A4 | Tìm kiếm/lọc là các nhánh tương tác trong UC10; nhập ngôn ngữ tự nhiên là nhánh trong UC09; giải thích được yêu cầu trong UC37/46. | Nếu các thao tác này là màn hình/luồng độc lập, bỏ `extend` và giữ actor association. |
| A5 | External AI Service và Notification Service là hệ thống ngoài ranh giới SPWPOS, giao tiếp với ứng dụng. | Nếu Notification Service chỉ là module nội bộ, bỏ actor NS. Nếu gửi/nhận thông báo nằm trong chính hệ thống, mô tả ở thiết kế nội bộ. |
| A6 | User có thể chủ động yêu cầu UC45; các thay đổi lịch cũng có thể kích hoạt nó tự động. | Nếu UC45 chỉ chạy tự động, bỏ đường User–UC45; giữ quy tắc sự kiện và các UC mà User thực sự sử dụng để xem/áp dụng đề xuất. |
| A7 | UC44, UC56, UC58 là hành vi được bao gồm, chưa có tương tác trực tiếp riêng với User. | Nếu có một chức năng độc lập cho User yêu cầu kiểm tra xung đột/ước lượng, phục hồi association đó và bổ sung luồng tương tác tương ứng. |

UC44/56/58 được giữ vì cần truy vết ID gốc. `supporting` chỉ là phân loại cục bộ;
khi giảng viên yêu cầu chỉ mô hình mục tiêu người dùng, có thể chuyển chúng vào
đặc tả luồng xử lý và thiết kế, đồng thời giữ bảng ánh xạ để tránh mất yêu cầu.

## Actor và tiền điều kiện

- User: tất cả UC ngoài Administration, trừ ba hành vi supporting ở giả định A7.
- Administrator: UC69–UC72. Không tự suy diễn Administrator kế thừa toàn bộ
  quyền User. Đăng nhập của quản trị viên chưa được mở rộng thêm vào danh mục.
  Nếu dùng UC02 chung, nhóm cần thêm association Admin–UC02 theo đặc tả xác nhận.
- External AI Service: UC25, UC26; giả định dịch vụ ngoài.
- Notification Service: UC65–UC68; giả định dịch vụ ngoài.
- Các chức năng User có dữ liệu cá nhân yêu cầu phiên đăng nhập hợp lệ.
  UC01/02/04/05 thuộc nhóm trước đăng nhập; không vẽ `include Login` cho mọi UC.
- UC38: đề xuất hợp lệ, thuộc User, có thể áp dụng; UC47: tương tự cho đề xuất
  điều chỉnh. Trạng thái sau khi xem không được biểu diễn bằng một đường `extend`.
- UC70/71: tài khoản đích tồn tại và trạng thái hiện tại cho phép thao tác;
  tìm kiếm tài khoản trước đó là một cách tìm mục tiêu, không phải `extend` mặc định.

## Điểm mở rộng đã đặt

| UC gốc | Extension point | Hành vi được chèn và điều kiện |
|---|---|---|
| UC09 Create Task | task input | UC25 khi User chọn nhập bằng ngôn ngữ tự nhiên |
| UC10 View Task List | list refinement | UC14 khi nhập từ khóa; UC15 khi chọn tiêu chí lọc |
| UC37 Review Proposed Plan | proposal explanation | UC48 khi User yêu cầu giải thích |
| UC46 Review Reschedule Proposal | proposal explanation | UC48 khi User yêu cầu giải thích |

Đây là các điểm chèn được đề xuất; cần cùng tên trong đặc tả use case của nhóm.
Mũi tên `extend` hướng về UC gốc; mũi tên `include` hướng về hành vi được bao gồm.

## Sự kiện và thứ tự thao tác đã tách khỏi sơ đồ

| Sự kiện/luồng | Cách ghi trong đặc tả |
|---|---|
| UC04: yêu cầu đặt lại mật khẩu; UC05: dùng liên kết/token để đặt mật khẩu mới | UC05 có tiền điều kiện token hợp lệ. Không dùng đường UC04→UC05 để chỉ thứ tự. |
| Xem danh sách → mở chi tiết UC11 | Luồng màn hình/tiền điều kiện đối tượng tồn tại. |
| Xem đề xuất UC37/46 → áp dụng UC38/47 | Hai mục tiêu liên quan, có điều kiện trạng thái đề xuất; không mặc định là mở rộng. |
| Tạo task, đổi thời hạn/thời lượng, hoàn thành/skip phiên, đổi availability/fixed event | Quy tắc yêu cầu đánh giá lại lịch hoặc tạo đề xuất UC45 theo cấu hình. |
| Phát hiện rủi ro/xung đột quan trọng | Quy tắc tạo cảnh báo UC67, kể cả khi User không mở màn hình phân tích. |
| Lịch thay đổi sau khi áp dụng đề xuất | Quy tắc UC68 theo cài đặt thông báo; không tự giả định mọi lần áp dụng đều gửi thông báo. |
| UC26 phân rã task lớn | Luồng riêng trên task đã chọn; AI trả về đề xuất, User xác nhận trước khi lưu subtasks. Đây là đề xuất cần xác nhận trong đặc tả. |

## Kiểm toán các quan hệ cũ

Giữ 8/17 `include` và 5/22 `extend`. Bỏ 9 `include` và 17 `extend` vì chưa đủ
căn cứ để coi chúng là gọi bắt buộc hoặc chèn vào một use case đang thực thi.

| Loại | Quan hệ | Quyết định | Lý do |
|---|---|---|---|
| `include` | UC09 → UC58 | Bỏ đường | Chưa xác nhận mọi lần tạo task đều phải lấy ước lượng cá nhân hóa. |
| `include` | UC36 → UC58 | Giữ | Giữ theo A1. |
| `include` | UC61 → UC58 | Bỏ đường | Dùng dữ liệu/kết quả của một chức năng chưa chứng minh việc gọi toàn bộ use case xem/đánh giá đó là bắt buộc. |
| `include` | UC61 → UC60 | Bỏ đường | Dùng dữ liệu/kết quả của một chức năng chưa chứng minh việc gọi toàn bộ use case xem/đánh giá đó là bắt buộc. |
| `include` | UC36 → UC44 | Giữ | Giữ theo A2. |
| `include` | UC39 → UC44 | Giữ | Giữ theo A2. |
| `include` | UC40 → UC44 | Giữ | Giữ theo A2. |
| `include` | UC43 → UC44 | Giữ | Giữ theo A2. |
| `include` | UC45 → UC44 | Giữ | Giữ theo A2. |
| `include` | UC49 → UC44 | Giữ | Giữ theo A2. |
| `include` | UC49 → UC61 | Bỏ đường | Dùng dữ liệu/kết quả của một chức năng chưa chứng minh việc gọi toàn bộ use case xem/đánh giá đó là bắt buộc. |
| `include` | UC62 → UC61 | Bỏ đường | Dùng dữ liệu/kết quả của một chức năng chưa chứng minh việc gọi toàn bộ use case xem/đánh giá đó là bắt buộc. |
| `include` | UC63 → UC61 | Bỏ đường | Dùng dữ liệu/kết quả của một chức năng chưa chứng minh việc gọi toàn bộ use case xem/đánh giá đó là bắt buộc. |
| `include` | UC53 → UC56 | Giữ | Giữ theo A3. |
| `include` | UC64 → UC59 | Bỏ đường | Dùng dữ liệu/kết quả của một chức năng chưa chứng minh việc gọi toàn bộ use case xem/đánh giá đó là bắt buộc. |
| `include` | UC64 → UC60 | Bỏ đường | Dùng dữ liệu/kết quả của một chức năng chưa chứng minh việc gọi toàn bộ use case xem/đánh giá đó là bắt buộc. |
| `include` | UC64 → UC57 | Bỏ đường | Dùng dữ liệu/kết quả của một chức năng chưa chứng minh việc gọi toàn bộ use case xem/đánh giá đó là bắt buộc. |
| `extend` | UC04 → UC02 | Bỏ đường | Khôi phục mật khẩu là mục tiêu độc lập; liên kết từ màn hình login chưa đủ để xác định extend. |
| `extend` | UC11 → UC10 | Bỏ đường | Mở chi tiết từ danh sách là điều hướng, chưa có đặc tả điểm chèn. |
| `extend` | UC14 → UC10 | Giữ | Giữ theo A4; đã định nghĩa extension point của UC gốc. |
| `extend` | UC15 → UC10 | Giữ | Giữ theo A4; đã định nghĩa extension point của UC gốc. |
| `extend` | UC25 → UC09 | Giữ | Giữ theo A4; đã định nghĩa extension point của UC gốc. |
| `extend` | UC26 → UC20 | Bỏ đường | Phân rã task là luồng đề xuất nhiều subtasks, chưa đủ căn cứ mở rộng việc tạo một subtask. |
| `extend` | UC38 → UC37 | Bỏ đường | Áp dụng đề xuất là mục tiêu tiếp theo với tiền điều kiện trạng thái đề xuất. |
| `extend` | UC47 → UC46 | Bỏ đường | Áp dụng đề xuất là mục tiêu tiếp theo với tiền điều kiện trạng thái đề xuất. |
| `extend` | UC48 → UC37 | Giữ | Giữ theo A4; đã định nghĩa extension point của UC gốc. |
| `extend` | UC48 → UC46 | Giữ | Giữ theo A4; đã định nghĩa extension point của UC gốc. |
| `extend` | UC45 → UC09 | Bỏ đường | Sự kiện kích hoạt đánh giá lại lịch; chưa chứng minh hành vi chèn trong luồng gốc. |
| `extend` | UC45 → UC12 | Bỏ đường | Sự kiện kích hoạt đánh giá lại lịch; chưa chứng minh hành vi chèn trong luồng gốc. |
| `extend` | UC45 → UC53 | Bỏ đường | Sự kiện kích hoạt đánh giá lại lịch; chưa chứng minh hành vi chèn trong luồng gốc. |
| `extend` | UC45 → UC54 | Bỏ đường | Sự kiện kích hoạt đánh giá lại lịch; chưa chứng minh hành vi chèn trong luồng gốc. |
| `extend` | UC45 → UC28 | Bỏ đường | Sự kiện kích hoạt đánh giá lại lịch; chưa chứng minh hành vi chèn trong luồng gốc. |
| `extend` | UC45 → UC32 | Bỏ đường | Sự kiện kích hoạt đánh giá lại lịch; chưa chứng minh hành vi chèn trong luồng gốc. |
| `extend` | UC55 → UC53 | Bỏ đường | Cập nhật tiến độ là mục tiêu độc lập; chưa chứng minh nhánh chỉ xuất hiện trong UC53. |
| `extend` | UC67 → UC62 | Bỏ đường | Thông báo theo sự kiện/cấu hình, có thể chạy bất đồng bộ; không phải mở rộng một màn hình đang xem. |
| `extend` | UC67 → UC44 | Bỏ đường | Thông báo theo sự kiện/cấu hình, có thể chạy bất đồng bộ; không phải mở rộng một màn hình đang xem. |
| `extend` | UC68 → UC47 | Bỏ đường | Thông báo theo sự kiện/cấu hình, có thể chạy bất đồng bộ; không phải mở rộng một màn hình đang xem. |
| `extend` | UC70 → UC69 | Bỏ đường | Khóa/mở khóa là thao tác trên tài khoản đích; mở màn hình từ kết quả tìm kiếm là điều hướng. |
| `extend` | UC71 → UC69 | Bỏ đường | Khóa/mở khóa là thao tác trên tài khoản đích; mở màn hình từ kết quả tìm kiếm là điều hướng. |

## Phần còn thiếu để chốt báo cáo SWP391

- Đặc tả từng UC theo template lớp: actor, trigger, preconditions, main flow,
  alternative/exception flows, postconditions, business rules.
- Sự thống nhất giữa sơ đồ, danh mục chức năng, screen flow, API/code và testcase.
- Xác nhận các giả định A1–A7 từ báo cáo nghiệp vụ hoặc phản hồi giảng viên.
- Nếu template yêu cầu sơ đồ theo actor, dùng bảng actor trong USE_CASE_INDEX.md
  để tạo thêm góc nhìn theo role; không đổi ID hay đếm lại các UC tham chiếu.

Database/ và các công cụ DB được giữ nguyên về byte, chưa được kiểm toán lại
trong lần cải thiện mô hình Use Case này.
