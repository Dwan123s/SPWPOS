"""Render Use Case sources as SVG and PNG using a locally supplied PlantUML jar."""
from pathlib import Path
import argparse
import subprocess
import sys
import math
import shutil
import xml.etree.ElementTree as ET
import route_uc
import gen_uc
import full_system_uc

def repair_canvas(source, svg_path, png_path):
    """Correct Smetana's negative system-boundary bounds without changing links."""
    namespace = 'http://www.w3.org/2000/svg'
    ET.register_namespace('', namespace)
    ET.register_namespace('xlink', 'http://www.w3.org/1999/xlink')
    parser = ET.XMLParser(target=ET.TreeBuilder(insert_comments=True))
    tree = ET.parse(svg_path, parser=parser)
    svg = tree.getroot()
    rects = [child for g in svg.iter(f'{{{namespace}}}g') if g.get('class') == 'cluster'
             for child in g if child.tag == f'{{{namespace}}}rect']
    minimum = min(float(r.get('y', '0')) for r in rects)
    if minimum >= 65:
        return
    inkscape = shutil.which('inkscape')
    if not inkscape:
        raise RuntimeError('Install Inkscape to correct the Smetana canvas bounds.')
    shift = 80 - minimum
    body = next(g for g in svg if g.tag == f'{{{namespace}}}g')
    body.set('transform', f'translate(0,{shift})')
    title = next(g for g in body if g.get('class') == 'title')
    baseline = float(next(iter(title)).get('y'))
    title.set('transform', f'translate(0,{minimum - 30 - baseline})')
    x, y, width, height = map(float, svg.get('viewBox').split())
    height += shift
    svg.set('viewBox', f'{x} {y} {width} {height}')
    svg.set('width', f'{width}px')
    svg.set('height', f'{height}px')
    svg.set('style', f'width:{width}px;height:{height}px;background:#FFFFFF;')
    tree.write(svg_path, encoding='unicode')

parser = argparse.ArgumentParser()
parser.add_argument('--jar', required=True, type=Path, help='Path to plantuml.jar')
parser.add_argument('--only-complete', action='store_true', help='Reuse the eight existing feature views')
args = parser.parse_args()
root = Path(__file__).resolve().parent.parent
subprocess.run([sys.executable, str(root / 'Tools' / 'gen_uc.py')], check=True)
jar = args.jar.resolve()
if not jar.is_file():
    parser.error('PlantUML jar does not exist')
sources = sorted(root / 'Sources' / name for name in gen_uc.all_sources() if not name.startswith('SPWPOS_UseCase_00_'))
if args.only_complete:sources=[]
for extension in ('svg',):
    if sources:
        subprocess.run(['java', '-jar', str(jar), '-charset', 'UTF-8', '-t' + extension,
                        '-o', '../UseCase', *map(str, sources)], check=True)
def rasterize(source,svg_path,png_path):
    svg=ET.parse(svg_path).getroot()
    width,height=map(float,(svg.get('width').removesuffix('px'),svg.get('height').removesuffix('px')))
    inkscape=shutil.which('inkscape')
    if not inkscape:raise RuntimeError('Install Inkscape to render routed SVG images.')
    subprocess.run([inkscape,str(svg_path),'--export-type=png','--export-filename='+str(png_path),
                    '--export-width='+str(math.ceil(width)),'--export-height='+str(math.ceil(height)),
                    '--export-background=#FFFFFF','--export-background-opacity=1'],check=True,capture_output=True)
    from PIL import Image,PngImagePlugin
    with Image.open(png_path) as image:
        image.load();detached=image.copy()
    metadata=PngImagePlugin.PngInfo()
    metadata.add_text('plantuml',source.read_text(),zip=True)
    cache=root.parent/'render-cache'
    cache.mkdir(exist_ok=True)
    temporary=cache/png_path.name
    detached.save(temporary,pnginfo=metadata)
    temporary.replace(png_path)
    temporary.unlink(missing_ok=True)
for source in sources:
    svg_path=root / 'UseCase' / (source.stem + '.svg')
    png_path=root / 'UseCase' / (source.stem + '.png')
    repair_canvas(source, svg_path, png_path)
    counts=route_uc.route_file(svg_path)
    rasterize(source,svg_path,png_path)
    print(source.stem,counts)
full_svg=full_system_uc.build(root)
rasterize(root / 'Sources' / (full_svg.stem+'.puml'),full_svg,full_svg.with_suffix('.png'))
print('Rendered all 9 Use Case views as SVG and PNG.')
