# Single source of truth for the 72 use cases and their relationships (from the report).
SUBSYSTEMS = [
 ("ACC","Account & Profile"),
 ("TASK","Task Management"),
 ("TIME","Time Management"),
 ("PLAN","Planning & Scheduling"),
 ("EXEC","Execution & Feedback"),
 ("INTEL","Intelligence & Personalization"),
 ("NOTI","Notification"),
 ("ADMIN","Administration"),
]
SUBNAME = dict(SUBSYSTEMS)

RAW = """
ACC|1|Register Account
ACC|2|Login
ACC|3|Logout
ACC|4|Request Password Reset
ACC|5|Reset Password
ACC|6|Change Password
ACC|7|View Profile
ACC|8|Update Profile
TASK|9|Create Task
TASK|10|View Task List
TASK|11|View Task Details
TASK|12|Update Task
TASK|13|Delete Task
TASK|14|Search Tasks
TASK|15|Filter Tasks
TASK|16|Change Task Status
TASK|17|Create Task Category
TASK|18|Update Task Category
TASK|19|Delete Task Category
TASK|20|Create Subtask
TASK|21|Update Subtask
TASK|22|Delete Subtask
TASK|23|Add Task Dependency
TASK|24|Remove Task Dependency
TASK|25|Capture Task Using Natural Language
TASK|26|Break Down Complex Task
TIME|27|Set Weekly Availability
TIME|28|Add Availability Exception
TIME|29|Update Availability Exception
TIME|30|Remove Availability Exception
TIME|31|Create Fixed Event
TIME|32|Update Fixed Event
TIME|33|Delete Fixed Event
TIME|34|View Personal Calendar
TIME|35|Set Work Preferences
PLAN|36|Generate Work Plan
PLAN|37|Review Proposed Plan
PLAN|38|Apply Proposed Plan
PLAN|39|Move Work Session
PLAN|40|Change Work Session Duration
PLAN|41|Lock Work Session
PLAN|42|Unlock Work Session
PLAN|43|Split Work Session
PLAN|44|Detect Scheduling Conflict
PLAN|45|Generate Reschedule Proposal
PLAN|46|Review Reschedule Proposal
PLAN|47|Apply Reschedule Proposal
PLAN|48|Explain Scheduling Decision
PLAN|49|Run What-if Scenario
EXEC|50|Start Work Session
EXEC|51|Pause Work Session
EXEC|52|Resume Work Session
EXEC|53|Complete Work Session
EXEC|54|Skip Work Session
EXEC|55|Update Task Progress
EXEC|56|Record Actual Work Duration
EXEC|57|Review Planned vs Actual Performance
INTEL|58|Get Personalized Duration Estimate
INTEL|59|Review Estimation Bias
INTEL|60|Review Effective Capacity
INTEL|61|View Workload Analysis
INTEL|62|View Overload Risk
INTEL|63|View Task Completion Risk
INTEL|64|View Personal Productivity Insights
NOTI|65|Receive Deadline Notification
NOTI|66|Receive Upcoming Work Session Reminder
NOTI|67|Receive Workload Warning
NOTI|68|Receive Schedule Change Notification
ADMIN|69|Search User Accounts
ADMIN|70|Lock User Account
ADMIN|71|Unlock User Account
ADMIN|72|View System Status
"""
UC = {}
for line in RAW.strip().splitlines():
    s,n,name = line.split("|")
    UC[int(n)] = dict(id=int(n), sub=s, name=name)
assert len(UC)==72

# Revised relationships: only behavior reuse / insertion, never temporal order.
# Business assumptions and removed relations are documented in MODEL_REVIEW.md.
SUPPORTING_UCS = {44, 56, 58}
INCLUDE = [
    (36, 58, "A1: planner uses a personalized estimate"),
    (36, 44, "A2: validate candidate schedule"),
    (39, 44, "A2: validate moved session"),
    (40, 44, "A2: validate changed duration"),
    (43, 44, "A2: validate split sessions"),
    (45, 44, "A2: validate reschedule proposal"),
    (49, 44, "A2: validate hypothetical schedule"),
    (53, 56, "A3: completion records elapsed duration"),
]
# The named extension point belongs to the base UC.
EXTENSION_POINTS = {
    9: "task input",
    10: "list refinement",
    37: "proposal explanation",
    46: "proposal explanation",
}
EXTEND = [
    (14, 10, "user enters a search keyword"),
    (15, 10, "user chooses filter criteria"),
    (25, 9, "user selects natural-language input"),
    (48, 37, "user requests an explanation"),
    (48, 46, "user requests an explanation"),
]
USER_UCS = [n for n in UC if UC[n]['sub'] != "ADMIN" and n not in SUPPORTING_UCS]
ADMIN_UCS = [69, 70, 71, 72]
AI_UCS = [25, 26]
NOTI_SVC_UCS = [65, 66, 67, 68]

