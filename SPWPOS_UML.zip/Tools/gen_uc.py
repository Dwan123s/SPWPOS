"""Generate all Use Case sources from usecases.py, independent of cwd."""
from pathlib import Path
import argparse
import textwrap
import usecases as U

HEAD = """@startuml
!pragma layout smetana
left to right direction
skinparam dpi 150
skinparam shadowing false
skinparam defaultFontName DejaVu Sans
skinparam defaultFontSize 12
skinparam packageStyle rectangle
skinparam backgroundColor #FFFFFF
skinparam ArrowColor #475569
skinparam ArrowFontSize 10
skinparam nodesep 20
skinparam ranksep 48
skinparam linetype polyline
skinparam padding 8
skinparam usecase {
  BackgroundColor #FFFFFF
  BorderColor #475569
  FontColor #172033
}
skinparam actor {
  BorderColor #334155
  FontColor #172033
}
skinparam rectangle {
  BackgroundColor #FAFCFF
  BorderColor #64748B
  FontColor #172033
}
skinparam legend {
  BackgroundColor #F1F5F9
  BorderColor #CBD5E1
  FontSize 10
}
"""

def uid(n):
    return f"UC{n:02d}"

def label(n):
    name = "\\n".join(textwrap.wrap(U.UC[n]['name'], width=28))
    value = uid(n) + "\\n" + name
    if n in U.EXTENSION_POINTS:
        value += "\\n--\\nextension points\\n" + U.EXTENSION_POINTS[n]
    return value

def uc_decl(n, referenced=False):
    tags = " <<supporting>>" if n in U.SUPPORTING_UCS else ""
    style = " #EEF2F7;line.dashed;line:94A3B8" if referenced else (" #EAF5EF" if n in U.SUPPORTING_UCS else "")
    return f'usecase "{label(n)}" as {uid(n)}{tags}{style}'

def actors(shown):
    lines = []
    if set(shown) & set(U.USER_UCS): lines.append('actor "User" as User')
    if set(shown) & set(U.ADMIN_UCS): lines.append('actor "Administrator" as Admin')
    if set(shown) & set(U.AI_UCS): lines.append('actor "External AI Service" as AI <<secondary>>')
    if set(shown) & set(U.NOTI_SVC_UCS): lines.append('actor "Notification Service" as NS <<secondary>>')
    return lines

def actor_links(mine):
    lines = []
    for n in mine:
        if n in U.USER_UCS: lines.append(f"User -- {uid(n)}")
        if n in U.ADMIN_UCS: lines.append(f"Admin -- {uid(n)}")
        if n in U.AI_UCS: lines.append(f"{uid(n)} -- AI")
        if n in U.NOTI_SVC_UCS: lines.append(f"{uid(n)} -- NS")
    return lines

def rel_lines(shown, mine):
    lines = []
    for b, i, _ in U.INCLUDE:
        if b in shown and i in shown and (b in mine or i in mine):
            lines.append(f"{uid(b)} ..> {uid(i)} : <<include>>")
    for e, b, c in U.EXTEND:
        if e in shown and b in shown and (e in mine or b in mine):
            lines.append(f"{uid(e)} ..> {uid(b)} : <<extend>>\\n{{{c}}}")
    return lines

def legend(has_references=False):
    lines = ["legend bottom", "  Solid line: actor participation; arrows only for include / extend.",
             "  Supporting: reused system behavior; not a direct User interaction."]
    if has_references:
        lines.append("  Grey dashed ellipse: same system, owned by another feature group.")
    lines += ["  Login is a precondition, not an include relation.", "endlegend"]
    return "\n".join(lines)

def subsystem_diagram(code):
    mine = {n for n in U.UC if U.UC[n]['sub'] == code}
    refs = set()
    for a, b, _ in U.INCLUDE + U.EXTEND:
        if a in mine and b not in mine: refs.add(b)
        # Only a supporting behavior needs its external caller displayed here.
        if b in mine and b in U.SUPPORTING_UCS and a not in mine: refs.add(a)
    shown = mine | refs
    lines = [HEAD, f"title SPWPOS | {U.SUBNAME[code]} ({uid(min(mine))}-{uid(max(mine))})"]
    lines += actors(shown)
    lines.append('rectangle "SPWPOS System" {')
    lines += ["  " + uc_decl(n) for n in sorted(mine)]
    lines += ["  " + uc_decl(n, True) for n in sorted(refs)]
    lines.append("}")
    lines += actor_links(sorted(shown))
    lines += rel_lines(shown, mine)
    lines += [legend(bool(refs)), "@enduml"]
    return "\n".join(lines)

def complete_diagram():
    lines = [HEAD, "title SPWPOS | Complete System Use Case Diagram (UC01-UC72)"]
    lines += actors(set(U.UC))
    lines.append('rectangle "SPWPOS System" {')
    for code,name in U.SUBSYSTEMS:
        lines.append(f'  package "{name}" as P_{code} {{')
        lines += ['    ' + uc_decl(n) for n in U.UC if U.UC[n]['sub']==code]
        lines.append('  }')
    lines.append("}")
    lines += actor_links(sorted(U.UC))
    lines += rel_lines(set(U.UC),set(U.UC))
    lines += [legend(), "@enduml"]
    return "\n".join(lines)

def all_sources():
    result = {"SPWPOS_UseCase_00_Complete_System.puml": complete_diagram()}
    for i, (code, _) in enumerate(U.SUBSYSTEMS, 1):
        result[f"SPWPOS_UseCase_{i:02d}_{code}.puml"] = subsystem_diagram(code)
    return result

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=Path(__file__).resolve().parent.parent / "Sources")
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    for name, content in all_sources().items():
        (args.output / name).write_text(content + "\n", encoding="utf-8")
    print(f"Generated {len(all_sources())} Use Case sources in {args.output}")
