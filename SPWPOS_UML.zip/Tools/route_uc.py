"""Draw straight/orthogonal UML links with exact ellipse-boundary endpoints."""
import heapq
import math
import re
from pathlib import Path
import xml.etree.ElementTree as ET

NS = 'http://www.w3.org/2000/svg'
TAG = lambda name: f'{{{NS}}}{name}'
ACTORS = {'User', 'Admin', 'AI', 'NS'}
NUMBER = r'-?\d+(?:\.\d+)?'

def node_info(group):
    alias = group.get('data-entity')
    ellipse = next(group.iter(TAG('ellipse')))
    cx, cy, rx, ry = (float(ellipse.get(k)) for k in ('cx', 'cy', 'rx', 'ry'))
    translation=re.search(r'translate\(([^)]+)\)',group.get('transform',''))
    shift=tuple(map(float,re.findall(NUMBER,translation[1]))) if translation else (0,0)
    dx,dy=shift if len(shift)==2 else (shift[0],0)
    cx+=dx;cy+=dy
    if alias not in ACTORS:
        return {'id': alias, 'actor': False, 'cx':cx, 'cy':cy, 'rx':rx, 'ry':ry,
                'box': (cx-rx, cy-ry, cx+rx, cy+ry)}
    body = next(group.iter(TAG('path')))
    coords = [tuple(map(float, re.findall(NUMBER, item))) for item in re.findall(r'[ML]([^ML]+)', body.get('d'))]
    coords=[(x+dx,y+dy) for x,y in coords]
    arm_left, arm_right = coords[2], coords[3]
    xs = [p[0] for p in coords] + [cx-rx, cx+rx]
    ys = [p[1] for p in coords] + [cy-ry, cy+ry]
    for t in group.iter(TAG('text')):
        x, y = float(t.get('x'))+dx, float(t.get('y'))+dy
        xs.extend([x, x+float(t.get('textLength', '0'))])
        ys.extend([y-float(t.get('font-size', '12')), y])
    return {'id':alias, 'actor':True, 'cx':cx, 'cy':arm_left[1],
            'arms':(arm_left,arm_right), 'box':(min(xs),min(ys),max(xs),max(ys))}

def anchor(node, toward):
    if node['actor']:
        return node['arms'][1 if toward[0]>=node['cx'] else 0]
    dx, dy = toward[0]-node['cx'], toward[1]-node['cy']
    scale = math.sqrt((dx/node['rx'])**2+(dy/node['ry'])**2)
    return (node['cx']+dx/scale, node['cy']+dy/scale)

def intersects_box(a,b,box):
    t0, t1 = 0.0, 1.0
    for start, end, lo, hi in ((a[0],b[0],box[0],box[2]),(a[1],b[1],box[1],box[3])):
        delta=end-start
        if abs(delta)<1e-9:
            if start<=lo or start>=hi: return False
        else:
            entry,leave=sorted(((lo-start)/delta,(hi-start)/delta))
            t0,t1=max(t0,entry),min(t1,leave)
            if t0>=t1: return False
    return True

def intersects_node(a,b,node):
    if node['actor']: return intersects_box(a,b,node['box'])
    rx,ry=node['rx']+5,node['ry']+5
    ax,ay=(a[0]-node['cx'])/rx,(a[1]-node['cy'])/ry
    dx,dy=(b[0]-a[0])/rx,(b[1]-a[1])/ry
    t=max(0,min(1,-(ax*dx+ay*dy)/(dx*dx+dy*dy)))
    return (ax+t*dx)**2+(ay+t*dy)**2<1

def horizontal_port(node, right):
    if node['actor']: return node['arms'][1 if right else 0]
    return (node['cx']+(node['rx'] if right else -node['rx']),node['cy'])

def orthogonal_route(source,target,nodes):
    right=target['cx']>=source['cx']
    a,b=horizontal_port(source,right),horizontal_port(target,not right)
    start=(a[0]+(14 if right else -14),a[1])
    finish=(b[0]+(-14 if right else 14),b[1])
    if source['actor']:
        start=((source['box'][2]+10) if right else (source['box'][0]-10),a[1])
    if target['actor']:
        finish=((target['box'][0]-10) if right else (target['box'][2]+10),b[1])
    boxes=[(n['box'][0]-7,n['box'][1]-7,n['box'][2]+7,n['box'][3]+7) for n in nodes.values()]
    xs=sorted({start[0],finish[0]}|{v for box in boxes for v in (box[0]-3,box[2]+3)})
    ys=sorted({start[1],finish[1]}|{v for box in boxes for v in (box[1]-3,box[3]+3)})
    origin=(xs.index(start[0]),ys.index(start[1]))
    goal=(xs.index(finish[0]),ys.index(finish[1]))
    def clear(p,q):
        return not any(intersects_box(p,q,box) for box in boxes)
    initial=(*origin,0)
    costs={initial:0}; previous={}; queue=[(0,initial)]; found=None
    cache={}
    while queue:
        cost,state=heapq.heappop(queue)
        if cost!=costs.get(state): continue
        i,j,direction=state
        if (i,j)==goal:
            found=state;break
        for ni,nj,axis in ((i-1,j,1),(i+1,j,1),(i,j-1,2),(i,j+1,2)):
            if not (0<=ni<len(xs) and 0<=nj<len(ys)): continue
            p,q=(xs[i],ys[j]),(xs[ni],ys[nj])
            key=tuple(sorted((p,q)))
            if key not in cache:cache[key]=clear(p,q)
            if not cache[key]:continue
            next_state=(ni,nj,axis)
            candidate=cost+abs(p[0]-q[0])+abs(p[1]-q[1])+(24 if direction and direction!=axis else 0)
            if candidate<costs.get(next_state,float('inf')):
                costs[next_state]=candidate;previous[next_state]=state;heapq.heappush(queue,(candidate,next_state))
    if found is None:
        raise ValueError(f"No orthogonal route for {source['id']} / {target['id']}")
    points=[]
    while found!=initial:
        points.append((xs[found[0]],ys[found[1]]));found=previous[found]
    points.append(start);points.reverse()
    points=[a]+points+[b]
    result=[]
    for p in points:
        if result and p==result[-1]:continue
        if len(result)>1 and ((result[-2][0]==result[-1][0]==p[0]) or (result[-2][1]==result[-1][1]==p[1])):
            result[-1]=p
        else:result.append(p)
    return result

def place_label(group,points,nodes,occupied):
    texts=list(group.findall(TAG('text')))
    if not texts:return
    font=max(float(t.get('font-size')) for t in texts)
    width=max(float(t.get('textLength')) for t in texts)
    height=font*1.3*len(texts)
    segments=sorted(zip(points,points[1:]),key=lambda pair:math.dist(*pair),reverse=True)
    choice=None
    for a,b in segments:
        for fraction in (.5,.35,.65,.2,.8):
            x=a[0]+(b[0]-a[0])*fraction
            y=a[1]+(b[1]-a[1])*fraction
            for offset in (-height-9,9):
                box=(x-width/2-5,y+offset-3,x+width/2+5,y+offset+height+3)
                collisions=sum(not (box[2]<n['box'][0]-4 or box[0]>n['box'][2]+4 or box[3]<n['box'][1]-4 or box[1]>n['box'][3]+4) for n in nodes.values())
                collisions+=sum(not(box[2]<old[0] or box[0]>old[2] or box[3]<old[1] or box[1]>old[3]) for old in occupied)
                score=(collisions,abs(fraction-.5))
                if choice is None or score<choice[0]:choice=(score,box,x,y+offset)
                if collisions==0:break
            if choice[0][0]==0:break
        if choice[0][0]==0:break
    _,box,x,top=choice
    occupied.append(box)
    background=ET.Element(TAG('rect'),{'x':str(box[0]),'y':str(box[1]),'width':str(box[2]-box[0]),'height':str(box[3]-box[1]),'fill':'#FFFFFF','stroke':'none'})
    group.insert(list(group).index(texts[0]),background)
    for i,t in enumerate(texts):
        t.set('x',str(x-float(t.get('textLength'))/2))
        t.set('y',str(top+font*(1+i*1.3)))

def route_file(svg_path, prescribed=None, extra_obstacles=None):
    ET.register_namespace('',NS)
    ET.register_namespace('xlink','http://www.w3.org/1999/xlink')
    parser=ET.XMLParser(target=ET.TreeBuilder(insert_comments=True))
    tree=ET.parse(svg_path,parser=parser);root=tree.getroot()
    nodes={g.get('data-entity'):node_info(g) for g in root.iter(TAG('g')) if g.get('class')=='entity'}
    for i,box in enumerate(extra_obstacles or []):
        nodes[f'header_{i}']={'id':f'header_{i}','actor':True,'box':box}
    counts={'straight':0,'orthogonal':0}
    occupied=[]
    for group in root.iter(TAG('g')):
        if group.get('class')!='link':continue
        source,target=nodes[group.get('data-entity-1')],nodes[group.get('data-entity-2')]
        center_source=(source['cx'],source['cy']);center_target=(target['cx'],target['cy'])
        a=anchor(source,center_target);b=anchor(target,a)
        if not source['actor']:a=anchor(source,b)
        blockers=[n for n in nodes.values() if n['id'] not in (source['id'],target['id'])]
        key=(source['id'],target['id'])
        if prescribed and key in prescribed:
            points=prescribed[key];counts['orthogonal']+=1
        elif any(intersects_node(a,b,n) for n in blockers):
            points=orthogonal_route(source,target,nodes);counts['orthogonal']+=1
        else:
            points=[a,b];counts['straight']+=1
        path=next(group.iter(TAG('path')))
        path.set('d',' '.join(('M' if i==0 else 'L')+f'{p[0]:.6f},{p[1]:.6f}' for i,p in enumerate(points)))
        for polygon in list(group.findall(TAG('polygon'))):group.remove(polygon)
        if not source['actor'] and not target['actor']:
            tip=points[-1];prior=points[-2];length=math.dist(tip,prior)
            dx,dy=(tip[0]-prior[0])/length,(tip[1]-prior[1])/length
            arms=[(tip[0]-12*dx+5*dy,tip[1]-12*dy-5*dx),tip,(tip[0]-12*dx-5*dy,tip[1]-12*dy+5*dx)]
            head=ET.Element(TAG('polyline'),{'points':' '.join(f'{x:.6f},{y:.6f}' for x,y in arms),'fill':'none','stroke':'#475569','stroke-width':'1.5625'})
            group.insert(1,head)
        for node,point in ((source,points[0]),(target,points[-1])):
            if not node['actor']:
                residual=((point[0]-node['cx'])/node['rx'])**2+((point[1]-node['cy'])/node['ry'])**2
                assert abs(residual-1)<1e-9
        place_label(group,points,nodes,occupied)
    tree.write(svg_path,encoding='unicode')
    return counts

if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('svg',type=Path);args=parser.parse_args()
    print(route_file(args.svg))
