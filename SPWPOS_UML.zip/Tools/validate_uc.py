"""Validate model references, source consistency, traceability and actor connections."""
from pathlib import Path
import re
import xml.etree.ElementTree as ET
import usecases as U
import gen_uc
import route_uc

root = Path(__file__).resolve().parent.parent
assert set(U.UC) == set(range(1, 73)), 'UC IDs must remain UC01-UC72'
assert not (set(U.USER_UCS) & U.SUPPORTING_UCS)
grouped = [n for code,_ in U.SUBSYSTEMS for n in U.UC if U.UC[n]['sub']==code]
assert sorted(grouped) == list(range(1, 73)), 'Feature groups must contain all 72 IDs exactly once'
for a, b, _ in U.INCLUDE + U.EXTEND:
    assert a in U.UC and b in U.UC and a != b
assert len({(a,b) for a,b,_ in U.INCLUDE}) == len(U.INCLUDE)
assert len({(a,b) for a,b,_ in U.EXTEND}) == len(U.EXTEND)
for _, base, _ in U.EXTEND:
    assert base in U.EXTENSION_POINTS, 'Extension point must be defined in base UC'
visited = set()
def walk(n, chain):
    assert n not in chain, 'Cycle in include behavior'
    for a,b,_ in U.INCLUDE:
        if a == n: walk(b, chain | {n})
for n in U.UC: walk(n, set())
for name, generated in gen_uc.all_sources().items():
    source = (root / 'Sources' / name).read_text()
    assert source == generated + '\n', f'Stale generated source: {name}'
    assert not re.search(r'^(?:User|Admin|AI|NS)\s+[-.]+>', source, re.M)
    assert not re.search(r'^UC(?:44|56|58)\s+--\s+User', source, re.M)
    declared = set(re.findall(r'\bas\s+(UC\d+|G_\w+)\b', source))
    for line in source.splitlines():
        if re.match(r'^(?:User|Admin|AI|NS|UC\d+|G_\w+)\s+[-.]', line):
            for ref in re.findall(r'\b(?:UC\d+|G_\w+)\b', line):
                assert ref in declared, f'Undeclared node {ref} in {name}'
    svg_path = root / 'UseCase' / name.replace('.puml', '.svg')
    svg = svg_path.read_text()
    assert 'Syntax Error' not in svg and 'An error has' not in svg
    tree = ET.fromstring(svg)
    nodes = {g.get('data-entity'): route_uc.node_info(g)
             for g in tree.iter('{http://www.w3.org/2000/svg}g') if g.get('class') == 'entity'}
    if name == 'SPWPOS_UseCase_00_Complete_System.puml':
        assert set(nodes)-route_uc.ACTORS == {f'UC{n:02d}' for n in range(1,73)}
        actual={(g.get('data-entity-1'),g.get('data-entity-2')) for g in tree.iter('{http://www.w3.org/2000/svg}g') if g.get('class')=='link'}
        expected={('User',f'UC{n:02d}') for n in U.USER_UCS}|{('Admin',f'UC{n:02d}') for n in U.ADMIN_UCS}|{(f'UC{n:02d}','AI') for n in U.AI_UCS}|{(f'UC{n:02d}','NS') for n in U.NOTI_SVC_UCS}|{(f'UC{a:02d}',f'UC{b:02d}') for a,b,_ in U.INCLUDE+U.EXTEND}
        assert actual==expected,'Complete diagram must show every association and relationship'
    for group in tree.iter('{http://www.w3.org/2000/svg}g'):
        group_id = group.get('id', '')
        if group_id.startswith('link_') and any(a in group_id.split('_') for a in ('User','Admin','AI','NS')):
            assert not list(group.iter('{http://www.w3.org/2000/svg}polygon')), f'Actor arrowhead in {name}'
            assert not list(group.iter('{http://www.w3.org/2000/svg}polyline')), f'Actor arrowhead in {name}'
        if group.get('class') == 'link':
            path = next(group.iter('{http://www.w3.org/2000/svg}path'))
            data = path.get('d')
            assert not re.search('[CQSAcqsa]', data), f'Curved connection in {name}'
            coordinates = [tuple(map(float, re.findall(route_uc.NUMBER, item)))
                           for item in re.findall(r'[ML]([^ML]+)', data)]
            for alias, point in ((group.get('data-entity-1'), coordinates[0]),
                                 (group.get('data-entity-2'), coordinates[-1])):
                node = nodes[alias]
                if not node['actor']:
                    residual = ((point[0]-node['cx'])/node['rx'])**2 + ((point[1]-node['cy'])/node['ry'])**2
                    assert abs(residual-1)<1e-6, f'Connection misses ellipse {alias} in {name}'
print('PASS: 72 IDs in the complete system, all associations/relationships, no actor arrowheads, defined extension points, acyclic includes and matching sources/SVG.')
print('PASS: all connection paths are straight/polyline, and every ellipse endpoint lies on its contour.')
