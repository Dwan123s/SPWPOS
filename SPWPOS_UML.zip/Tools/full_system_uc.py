"""Create one complete 72-UC canvas from the eight canonical feature views."""
from pathlib import Path
from copy import deepcopy
import math
import xml.etree.ElementTree as ET
from PIL import ImageFont
import usecases as U
import gen_uc
import route_uc as R

def build(root):
    ET.register_namespace('',R.NS)
    glyphs={};actor_glyphs={}
    for i,(code,_) in enumerate(U.SUBSYSTEMS,1):
        svg=ET.parse(root/'UseCase'/f'SPWPOS_UseCase_{i:02d}_{code}.svg').getroot()
        for g in svg.iter(R.TAG('g')):
            if g.get('class')!='entity':continue
            alias=g.get('data-entity')
            if alias in R.ACTORS:actor_glyphs.setdefault(alias,deepcopy(g))
            elif alias.startswith('UC') and U.UC[int(alias[2:])]['sub']==code:
                glyphs[alias]=deepcopy(g)
    assert set(glyphs)=={gen_uc.uid(n) for n in U.UC}
    info={alias:R.node_info(g) for alias,g in glyphs.items()}
    max_rx=max(n['rx'] for n in info.values())
    max_ry=max(n['ry'] for n in info.values())
    cell_w=2*max_rx+76;cell_h=2*max_ry+48
    block_w=2*cell_w+70;gap_x=110;gap_y=170
    rows=[]
    for row in range(2):
        rows.append(max(math.ceil(sum(u['sub']==code for u in U.UC.values())/(2 if sum(u['sub']==code for u in U.UC.values())>10 else 1)) for code,_ in U.SUBSYSTEMS[row*4:(row+1)*4]))
    heights=[100+row_count*cell_h for row_count in rows]
    start_x,start_y=280,230
    system_w=4*block_w+3*gap_x+80
    width=start_x+system_w+270
    bottom=start_y+sum(heights)+gap_y
    height=bottom+190
    svg=ET.Element(R.TAG('svg'),{'width':f'{width}px','height':f'{height}px','viewBox':f'0 0 {width} {height}','version':'1.1'})
    ET.SubElement(svg,R.TAG('title')).text='SPWPOS | Complete System Use Case Diagram (UC01-UC72)'
    metadata=ET.SubElement(svg,R.TAG('metadata'),{'id':'plantuml-source'})
    metadata.text=(root/'Sources'/'SPWPOS_UseCase_00_Complete_System.puml').read_text()
    ET.SubElement(svg,R.TAG('rect'),{'x':'0','y':'0','width':str(width),'height':str(height),'fill':'#FFFFFF'})
    def text(parent,value,x,y,size=22,bold=False):
        attrs={'x':str(x),'y':str(y),'font-family':'DejaVu Sans','font-size':str(size),'fill':'#172033','text-anchor':'middle'}
        if bold:attrs['font-weight']='bold'
        ET.SubElement(parent,R.TAG('text'),attrs).text=value
    text(svg,'SPWPOS | COMPLETE SYSTEM USE CASE DIAGRAM',width/2,58,34,True)
    text(svg,'UC01-UC72 | All individual use cases in one system boundary',width/2,98,21)
    system=ET.SubElement(svg,R.TAG('g'),{'class':'cluster','id':'cluster_SPWPOS','data-entity':'SPWPOS'})
    ET.SubElement(system,R.TAG('rect'),{'x':str(start_x-40),'y':'125','width':str(system_w),'height':str(bottom-100),'rx':'6','fill':'#FAFCFF','stroke':'#475569','stroke-width':'2'})
    text(system,'SPWPOS SYSTEM',start_x-40+system_w/2,164,28,True)
    positions={};headers=[]
    font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',24)
    for i,(code,name) in enumerate(U.SUBSYSTEMS):
        row,col=divmod(i,4)
        bx=start_x+col*(block_w+gap_x)
        by=start_y if row==0 else start_y+heights[0]+gap_y
        bh=heights[row]
        cluster=ET.SubElement(svg,R.TAG('g'),{'class':'cluster','data-entity':code,'id':f'cluster_{code}'})
        ET.SubElement(cluster,R.TAG('rect'),{'x':str(bx),'y':str(by),'width':str(block_w),'height':str(bh),'rx':'4','fill':'#FFFFFF','stroke':'#94A3B8','stroke-width':'1.5'})
        ids=[n for n in U.UC if U.UC[n]['sub']==code]
        text(cluster,name,bx+block_w/2,by+35,24,True)
        text(cluster,f'{gen_uc.uid(ids[0])}-{gen_uc.uid(ids[-1])}',bx+block_w/2,by+62,17)
        header_w=font.getlength(name)+35
        headers.append((bx+block_w/2-header_w/2,by+8,bx+block_w/2+header_w/2,by+68))
        columns=2 if len(ids)>10 else 1
        count_rows=math.ceil(len(ids)/columns)
        for j,n in enumerate(ids):
            column,index=divmod(j,count_rows)
            cx=bx+block_w/2 if columns==1 else bx+35+cell_w*(column+.5)
            cy=by+100+cell_h*(index+.5)
            alias=gen_uc.uid(n);g=glyphs[alias];old=info[alias]
            g.set('transform',f"translate({cx-old['cx']},{cy-old['cy']})")
            svg.append(g)
            positions[alias]={'bx':bx,'by':by,'bw':block_w,'bh':bh,'cx':cx,'cy':cy,'rx':old['rx'],
                              'left_rail':cx-max_rx-22,'right_rail':cx+max_rx+22,'row':row}
    actor_positions={'User':(105,(start_y+bottom)/2),
                     'Admin':(width-112,start_y+heights[0]+gap_y+heights[1]*.75),
                     'AI':(width-112,start_y+heights[0]*.25),
                     'NS':(width-112,start_y+heights[0]+gap_y+heights[1]*.3)}
    actors={}
    for alias,(x,y) in actor_positions.items():
        group=actor_glyphs[alias];old=R.node_info(group)
        group.set('transform',f"translate({x-old['cx']},{y-old['cy']})")
        actors[alias]=R.node_info(group);svg.append(group)
    prescribed={}
    label_font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',16)
    def link(a,b,kind=None,condition=None):
        group=ET.SubElement(svg,R.TAG('g'),{'class':'link','data-entity-1':a,'data-entity-2':b,'id':f'link_{a}_{b}'})
        style='stroke:#475569;stroke-width:1.5;'+('stroke-dasharray:8,7;' if kind else '')
        ET.SubElement(group,R.TAG('path'),{'d':'M0,0 L1,1','fill':'none','style':style})
        if kind:
            values=[f'«{kind}»']+([f'{{{condition}}}'] if condition else [])
            for value in values:
                t=ET.SubElement(group,R.TAG('text'),{'x':'0','y':'0','fill':'#172033','font-family':'DejaVu Sans','font-size':'16','textLength':str(label_font.getlength(value))})
                t.text=value
        return group
    for n in U.USER_UCS+U.ADMIN_UCS:
        alias=gen_uc.uid(n);p=positions[alias];actor='User' if n in U.USER_UCS else 'Admin'
        link(actor,alias)
        if actor=='User':
            arm=actors[actor]['arms'][1];end=(p['cx']-p['rx'],p['cy'])
            prescribed[(actor,alias)]=[arm,(190,arm[1]),(190,p['by']-40),(p['bx']-24,p['by']-40),
                                      (p['bx']-24,p['by']+78),(p['left_rail'],p['by']+78),
                                      (p['left_rail'],p['cy']),end]
        else:
            arm=actors[actor]['arms'][0];end=(p['cx']+p['rx'],p['cy']);rail=width-230;entry=p['bx']+p['bw']+24
            prescribed[(actor,alias)]=[arm,(rail,arm[1]),(rail,p['by']-40),(entry,p['by']-40),
                                      (entry,p['by']+78),(p['right_rail'],p['by']+78),(p['right_rail'],p['cy']),end]
    for actor,ids in (('AI',U.AI_UCS),('NS',U.NOTI_SVC_UCS)):
        for n in ids:
            alias=gen_uc.uid(n);p=positions[alias];link(alias,actor)
            arm=actors[actor]['arms'][0];start=(p['cx']+p['rx'],p['cy']);entry=p['bx']+p['bw']+30;rail=width-225
            prescribed[(alias,actor)]=[start,(p['right_rail'],p['cy']),(p['right_rail'],p['by']+89),
                                      (entry,p['by']+89),(entry,p['by']-66),(rail,p['by']-66),(rail,arm[1]),arm]
    for a,b,_ in U.INCLUDE:link(gen_uc.uid(a),gen_uc.uid(b),'include')
    for a,b,condition in U.EXTEND:link(gen_uc.uid(a),gen_uc.uid(b),'extend',condition)
    text(svg,'Solid line: actor association (no arrowhead) | Dashed open arrow: include / extend',width/2,bottom+80,20)
    text(svg,'Green supporting UC: reused system behavior | Line crossings are not extra UML nodes',width/2,bottom+113,20)
    path=root/'UseCase'/'SPWPOS_UseCase_00_Complete_System.svg'
    ET.ElementTree(svg).write(path,encoding='unicode')
    counts=R.route_file(path,prescribed,headers)
    print('Complete system:',len(glyphs),'individual UCs;',counts)
    return path
