# SPWPOS UML v2 - what changed and why

Source of truth: *Bao cao de tai SPWPOS - Phien ban 72 Use Case cu the* (72 use cases, 8 subsystems).

## Folder map
- `UseCase/` - `00_Overview` (actors + 8 subsystems + cross-subsystem dependencies) and `01..08` one diagram per subsystem. SVG (sharp, preferred) + PNG.
- `Database/` - `SPWPOS_Database_ER_v2` (crow's-foot ER diagram, SVG/PNG) and `SPWPOS_Database_Schema.sql` (DDL generated from the same spec).
- `Sources/` - editable PlantUML (`.puml`). Render: `java -jar plantuml.jar -tsvg *.puml`.
- `Tools/` - Python that generates the diagrams/SQL from one spec (`usecases.py`, `dbspec.py`) and `test_db.py` smoke test.

## 1. Use case diagrams - problems found and fixes
| Problem in old package | Fix in v2 |
|---|---|
| No use-case relationships at all: all 72 use cases were isolated ellipses | 17 `<<include>>` and 22 `<<extend>>` relationships drawn with correct arrow direction (tables below) |
| Actor symbol drawn 7x (User) in the main diagram | Each actor appears once per diagram |
| Association lines ran through use-case ellipses and struck out labels | Layered auto-layout; lines route around use cases |
| One 72-ellipse diagram could not show relationships legibly | Overview + 8 subsystem diagrams. A single diagram with ~64 User associations is unreadable, so it is not provided |
| Secondary actors not distinguished | External AI Service (UC25, UC26) and Notification Service (UC65-UC68) marked `<<secondary>>`, placed outside the boundary |

Not modeled as relationships on purpose: "requires login" (a precondition, not `<<include>>` of UC02); sequence such as UC04 -> UC05.

### `<<include>>` (base -> always-performed included use case)
| Base | Included |
|---|---|
| UC09 Create Task | UC58 Get Personalized Duration Estimate |
| UC36 Generate Work Plan | UC58 Get Personalized Duration Estimate |
| UC61 View Workload Analysis | UC58 Get Personalized Duration Estimate |
| UC61 View Workload Analysis | UC60 Review Effective Capacity |
| UC36 Generate Work Plan | UC44 Detect Scheduling Conflict |
| UC39 Move Work Session | UC44 Detect Scheduling Conflict |
| UC40 Change Work Session Duration | UC44 Detect Scheduling Conflict |
| UC43 Split Work Session | UC44 Detect Scheduling Conflict |
| UC45 Generate Reschedule Proposal | UC44 Detect Scheduling Conflict |
| UC49 Run What-if Scenario | UC44 Detect Scheduling Conflict |
| UC49 Run What-if Scenario | UC61 View Workload Analysis |
| UC62 View Overload Risk | UC61 View Workload Analysis |
| UC63 View Task Completion Risk | UC61 View Workload Analysis |
| UC53 Complete Work Session | UC56 Record Actual Work Duration |
| UC64 View Personal Productivity Insights | UC59 Review Estimation Bias |
| UC64 View Personal Productivity Insights | UC60 Review Effective Capacity |
| UC64 View Personal Productivity Insights | UC57 Review Planned vs Actual Performance |

### `<<extend>>` (optional extension -> base)
| Extension | Base | Condition |
|---|---|---|
| UC04 Request Password Reset | UC02 Login | forgot password |
| UC11 View Task Details | UC10 View Task List | select a task |
| UC14 Search Tasks | UC10 View Task List | enter keyword |
| UC15 Filter Tasks | UC10 View Task List | apply filter |
| UC25 Capture Task Using Natural Language | UC09 Create Task | input by sentence |
| UC26 Break Down Complex Task | UC20 Create Subtask | task is large |
| UC38 Apply Proposed Plan | UC37 Review Proposed Plan | user accepts |
| UC47 Apply Reschedule Proposal | UC46 Review Reschedule Proposal | user accepts |
| UC48 Explain Scheduling Decision | UC37 Review Proposed Plan | user asks why |
| UC48 Explain Scheduling Decision | UC46 Review Reschedule Proposal | user asks why |
| UC45 Generate Reschedule Proposal | UC09 Create Task | new task |
| UC45 Generate Reschedule Proposal | UC12 Update Task | deadline/duration changed |
| UC45 Generate Reschedule Proposal | UC53 Complete Work Session | finished early / over |
| UC45 Generate Reschedule Proposal | UC54 Skip Work Session | session skipped or missed |
| UC45 Generate Reschedule Proposal | UC28 Add Availability Exception | availability changed |
| UC45 Generate Reschedule Proposal | UC32 Update Fixed Event | event changed |
| UC55 Update Task Progress | UC53 Complete Work Session | user updates progress |
| UC67 Receive Workload Warning | UC62 View Overload Risk | risk > threshold |
| UC67 Receive Workload Warning | UC44 Detect Scheduling Conflict | important conflict |
| UC68 Receive Schedule Change Notification | UC47 Apply Reschedule Proposal | schedule changed |
| UC70 Lock User Account | UC69 Search User Accounts | from result |
| UC71 Unlock User Account | UC69 Search User Accounts | from result |

These relationships are my reading of the report text (e.g. section 21 data flow, section 12 reschedule triggers). Please check them against your team's intent; they are one list in `Tools/usecases.py`, so changing one is a one-line edit.

## 2. Database - problems found and fixes
Findings come from the old `SPWPOS_Database_UML.dot` read against the report.

| # | Old design problem (would break or block a feature) | v2 fix |
|---|---|---|
| 1 | `work_sessions.plan_id` mandatory: a reschedule proposal would insert duplicate sessions that collide with the applied calendar; no way to tell proposed from applied | Proposal and calendar separated: `work_plans` + `plan_items` (proposal) -> `work_sessions` (applied only), linked by `source_item_id`. Apply = one transaction |
| 2 | Sessions had no `user_id` (ownership/overlap checks needed 2 joins) | `work_sessions.user_id` added |
| 3 | Pause/resume stored as one `paused_duration_min`; timer cannot be restored, 1..* executions per session ambiguous | `session_executions` (0..1 per session, UNIQUE) + `execution_segments` (run intervals) |
| 4 | Dependency and parent-child links drawn incompletely (second FK of `task_dependencies` missing in the diagram) | Both FKs shown; CHECK predecessor <> successor; composite PK blocks duplicates |
| 5 | `task_type` free text in `tasks` and `task_type_biases`: a spelling difference silently breaks the bias lookup | `task_types` lookup table, real FKs |
| 6 | Only raw estimate stored; report says raw must be kept next to adjusted; no hard-deadline flag; deadline nullable although Quick Create requires it | `estimated_duration_min` (raw) + `adjusted_duration_min`/`adjustment_factor`; `is_hard_deadline`; `deadline` NOT NULL; soft delete `deleted_at` |
| 7 | Bias kept only as an aggregate; rolling/weighted update (section 34.5) and cold start cannot be recomputed | `estimation_observations` (1 row per completed task), `capacity_snapshots` (weekly), `avg_error_ratio` for the buffer |
| 8 | Report requires stored reason codes, old note marked risk as "transient"; explanations only as JSON blobs | `risk_assessments` + `risk_reasons`, `plan_item_reasons`, `plan_warnings` |
| 9 | UC72 needs failed jobs/error count and UC70/71 need an audit trail; none existed | `system_job_runs`, `account_status_logs` |
| 10 | Notifications: no dedupe (duplicate reminders), no link to plan, no per-user rules though report says "configured rule" | `dedupe_key` UNIQUE per user, `plan_id`, `notification_settings` |
| 11 | No CHECK/UNIQUE constraints (start<end, availability overlap start, category name, enums) | Added; see SQL |
| 12 | Unclear notation (`UUID -> users` in cells, ambiguous end labels) | Standard crow's-foot ER, `*` = NOT NULL |

Result: 28 tables (was 18). Still not persisted by design: what-if scenarios, ad-hoc conflict checks, AI suggestions before the user confirms.

### Verification
`Tools/test_db.py` loads the schema into SQLite (foreign keys ON) and runs the section 34.5 demo: availability, fixed event, tasks A/B/C, dependency, subtask, proposal, apply, paused execution (actual 180 min, bias 1.5), reschedule proposal with an unscheduled item, risk with reason, notification, failed job. It also confirms 10 invalid inserts are rejected. Tested on SQLite only; the DDL uses portable types (see header for PostgreSQL/SQL Server/MySQL adjustments).
Rules a DB cannot enforce (session overlap, dependency cycles, one-level subtasks, apply transaction) are listed at the end of the SQL as R1-R9.

## 3. Issues in the report itself (not changed)
- Section 34.2 says external AI is used for "UC17 and UC18"; the AI use cases are **UC25 and UC26**.
- UC44, UC56, UC58 are listed with Actor: User but are largely system actions; they are shown as included use cases with a User association, per the report.
- The Word report was not edited.
