# SPWPOS UML — thay đổi trong bản cải thiện

## Ảnh toàn hệ thống theo yêu cầu đã làm rõ

- Thay ảnh tóm tắt bằng SPWPOS_UseCase_00_Complete_System: đủ 72 ellipse và từng tên UC.
- Gom các UC vào 8 vùng chức năng trong cùng một ranh giới SPWPOS.
- Hiển thị đủ 75 actor association và 13 include/extend trong ảnh toàn hệ thống.
- Giữ 8 ảnh riêng theo nhóm; không dùng một ellipse đại diện thay cho nhiều UC.
- Bổ sung mã tạo canvas đầy đủ và kiểm tra mọi UC/quan hệ đều xuất hiện.


## Chỉnh đường nối theo phản hồi mới nhất

- Ưu tiên nét thẳng, dùng các đoạn vuông góc khi cần tránh actor/ellipse khác.
- Điểm đầu/cuối chạm đúng viền ellipse; actor association chạm cánh tay actor.
- Không dùng đường cong Bézier, không có đầu mũi tên trên actor association.
- Giữ đầu mũi tên mở cho include/extend, tiếp xúc đúng ellipse đích.
- Chuyển nhãn quan hệ đến tuyến mới; tạo lại cả PNG và SVG từ cùng đường nối.
- Thêm kiểm tra tự động các điểm chạm và việc không còn đường cong.
- Nội dung nghiệp vụ, ID và danh sách quan hệ của bản cải thiện trước giữ nguyên.

## Cải thiện mô hình trước đó

- Ảnh tóm tắt 10 mục tiêu của bản trước đã được thay bằng ảnh toàn hệ thống đủ 72 UC; bốn actor nằm ngoài ranh giới.
- Giữ đủ UC01–UC72 và tám góc nhìn chi tiết; bổ sung bảng nhóm chức năng và danh mục từng UC.
- Bỏ association trực tiếp User–UC44/56/58; đánh dấu ba hành vi supporting.
- Giữ 8 include và 5 extend theo giả định được công bố; bỏ 26 đường chưa đủ căn cứ.
- Đặt extension point trong UC09/10/37/46; không dùng extend để biểu diễn thứ tự.
- UC tham chiếu từ phân hệ khác nằm trong cùng ranh giới SPWPOS.
- Giảm quan hệ tham chiếu không cần thiết trong mỗi góc nhìn.
- Tạo lại toàn bộ PNG/SVG từ mã PlantUML đã sửa; xử lý khung hình âm của Smetana.
- Cập nhật generator, thêm renderer và kiểm tra cấu trúc/ID/association/source.
- Giữ nguyên Database/ và tất cả mã nguồn/công cụ DB.

Chi tiết: Documentation/MODEL_REVIEW.md.
Lịch sử v2: Documentation/CHANGE_HISTORY_v2.md; các quyết định quan hệ trong đó
chỉ là lịch sử, không phải mô hình hiện hành.
